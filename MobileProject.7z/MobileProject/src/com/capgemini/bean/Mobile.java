package com.capgemini.bean;

import java.util.Map;

public class Mobile {
private String mName;
//private String mName;
private double mPrice;
private int mQuantity;
public Mobile(String mName, double mPrice, int mQuantity) {
	super();
	this.mName = mName;
	this.mPrice = mPrice;
	this.mQuantity = mQuantity;
}
@Override
public String toString() {
	return "Mobile [mName=" + mName + ", mPrice=" + mPrice + ", mQuantity=" + mQuantity + "]";
}

}
