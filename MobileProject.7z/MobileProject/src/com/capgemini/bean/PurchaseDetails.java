package com.capgemini.bean;

import java.time.LocalDate;

public class PurchaseDetails {
	
	private String cName;
	private String mailId;
	private long phoneNo;
	private int mobileId;
	private int purchaseId;
	private LocalDate  date;
	public PurchaseDetails(String cName, String mailId, long phoneNo, int mobileId, int purchaseId, LocalDate date) {
		super();
		this.cName = cName;
		this.mailId = mailId;
		this.phoneNo = phoneNo;
		this.mobileId = mobileId;
		this.purchaseId = purchaseId;
		this.date = date;
	}
}
