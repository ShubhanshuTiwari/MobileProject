package com.capgemini.businesslogic;

import java.util.Map;

import com.capgemini.bean.PurchaseDetails;

public interface BusinessLogicInterface {

	
	boolean delete(int id);
	
	boolean addPurchaseDetails(PurchaseDetails pd);
	
	boolean update(int id);
	Map<Integer,Object> findAll();
	
	
	
}
