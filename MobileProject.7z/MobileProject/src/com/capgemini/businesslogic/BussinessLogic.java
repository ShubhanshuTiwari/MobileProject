package com.capgemini.businesslogic;

public class BussinessLogic {

	
	
	
}
