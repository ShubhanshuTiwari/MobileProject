package com.capgemini.businesslogic;

import java.util.Map;

import com.capgemini.bean.PurchaseDetails;
import com.capgemini.repository.MobileRepository;

public class BussinessLogic {

	MobileRepository repository;

	public BussinessLogic() {
		repository = new MobileRepository();
	}

	public boolean delete(int id) {
		return true;
	}

	public boolean addPurchaseDetails(PurchaseDetails pd) {
			
		return repository.addPurchaseDetails(pd);
	}

	public boolean update(int id) {
		return repository.update(0);
	}

	public Map<Integer, Object> findAll() {

		return repository.findAll();
	}
}
