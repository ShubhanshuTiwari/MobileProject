package com.capgemini.main;

import java.time.LocalDate;

import com.capgemini.bean.PurchaseDetails;
import com.capgemini.businesslogic.BussinessLogic;

public class Entry {
	static int count=1;
	
	public static void main(String[] args) {
		LocalDate date;	
		
		BussinessLogic bussinesslogic=new BussinessLogic();
		
		date=LocalDate.now();
		PurchaseDetails purcdetail1=new PurchaseDetails("Ram","ram@gmail.com",9450328639l,9,count++,date);
		PurchaseDetails purcdetail2=new PurchaseDetails("shyam","shyam@gmail.com",7408303225l,1,count++,date);
		PurchaseDetails purcdetail3=new PurchaseDetails("ghanshyam","ghanshyam@gmail.com",8090184394l,1,count++,date);
		bussinesslogic.addPurchaseDetails(purcdetail1);
		bussinesslogic.addPurchaseDetails(purcdetail2);
		bussinesslogic.addPurchaseDetails(purcdetail3);
		System.out.println(bussinesslogic.findAll());
	}
}
