package com.capgemini.repository;
import java.time.LocalDate;
import java.util.*;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetails;
public class MobileRepository {
	
	Map< Integer,Object> mobilemap1;
	Map< Integer,Object> purchaseDetails;
	LocalDate date;
	static int count=0;
	MobileRepository(){
		Mobile mobile1=new Mobile("nokia",26000,10);
		Mobile mobile2=new Mobile("samsung",16000,12);
		Mobile mobile3=new Mobile("Iphone",60000,6);
		Mobile mobile4=new Mobile("OnePlus",36000,8);
		this.mobilemap1 = new HashMap<Integer,Object>();
		mobilemap1.put(1, mobile1);
		mobilemap1.put(2, mobile2);
		mobilemap1.put(1, mobile3);
		mobilemap1.put(2, mobile4);
		date=LocalDate.now();
		PurchaseDetails purcdetail1=new PurchaseDetails("Ram","ram@gmail.com",9450328639l,1111,count++,date);
		PurchaseDetails purcdetail2=new PurchaseDetails("Ram","ram@gmail.com",9450328639l,1111,count++,date);
		PurchaseDetails purcdetail3=new PurchaseDetails("Ram","ram@gmail.com",9450328639l,1111,count++,date);
		PurchaseDetails purcdetail4=new PurchaseDetails("Ram","ram@gmail.com",9450328639l,1111,count++,date);
		purchaseDetails.put(1,purcdetail1);
		purchaseDetails.put(2,purcdetail2);
		purchaseDetails.put(3,purcdetail3);
		purchaseDetails.put(4,purcdetail4);
	}
	
	
	
	

	
	
	
	
	
	
//	public int a=11;
//	Mobile mobile1=new Mobile("nokia",2600,4);
//	Mobile mobile2=new Mobile("samsung",1600,2);
//	public Map< Integer,Object> mobilemap1 = new HashMap<Integer,Object>();
//	public Map< Integer,Object> mobilemap = new HashMap<Integer,Object>();
//	
//	public Map< Integer,Object> addMobile() {
//		mobilemap1.put(1, mobile1);
//		mobilemap1.put(2, mobile2);
//		return mobilemap1;
//	}
//	public void addPurchased() {
//		LocalDate date=LocalDate.now();
//		PurchaseDetails pd1=new PurchaseDetails("ram","abc@gmail.com",7408303,date,mobile1);
//		PurchaseDetails pd2=new PurchaseDetails("Shyam","abc@gmail.com",830302,date,mobile2);
//		
//		mobilemap.put(1, pd1);
//		mobilemap.put(2, pd2);
//	}
	
	
	
}
