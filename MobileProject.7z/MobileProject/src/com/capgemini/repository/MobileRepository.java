package com.capgemini.repository;


import java.util.*;

import com.capgemini.bean.Mobile;
import com.capgemini.bean.PurchaseDetails;

public class MobileRepository {

	Map<Integer, Object> mobilemap1;
	Map<Integer, Object> purchaseDetails=new HashMap<Integer,Object>();
	

	static int count = 1;

	public MobileRepository() {
		Mobile mobile1 = new Mobile("nokia", 26000, 10);
		Mobile mobile2 = new Mobile("samsung", 16000, 12);
		Mobile mobile3 = new Mobile("Iphone", 60000, 6);
		Mobile mobile4 = new Mobile("OnePlus", 36000, 8);
		this.mobilemap1 = new HashMap<Integer, Object>();
		mobilemap1.put(1, mobile1);
		mobilemap1.put(2, mobile2);
		mobilemap1.put(3, mobile3);
		mobilemap1.put(4, mobile4);
	}
	
	public boolean addPurchaseDetails(PurchaseDetails pd) {
		purchaseDetails.put(count, pd);
		count++;
		return true;
	}
	

	public boolean delete(int id) {
		return true;
	}

	

	public boolean update(int id) {
		return true;
	}

	public Map<Integer, Object> findAll() {
		return mobilemap1;
	}

	// public int a=11;
	// Mobile mobile1=new Mobile("nokia",2600,4);
	// Mobile mobile2=new Mobile("samsung",1600,2);
	// public Map< Integer,Object> mobilemap1 = new HashMap<Integer,Object>();
	// public Map< Integer,Object> mobilemap = new HashMap<Integer,Object>();
	//
	// public Map< Integer,Object> addMobile() {
	// mobilemap1.put(1, mobile1);
	// mobilemap1.put(2, mobile2);
	// return mobilemap1;
	// }
	// public void addPurchased() {
	// LocalDate date=LocalDate.now();
	// PurchaseDetails pd1=new
	// PurchaseDetails("ram","abc@gmail.com",7408303,date,mobile1);
	// PurchaseDetails pd2=new
	// PurchaseDetails("Shyam","abc@gmail.com",830302,date,mobile2);
	//
	// mobilemap.put(1, pd1);
	// mobilemap.put(2, pd2);
	// }

}
