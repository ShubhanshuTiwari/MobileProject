package com.capgemini.repository;

import java.util.List;
import java.util.Map;

import com.capgemini.bean.Mobile;



public interface MobileRepositoryInterface {
	
	
	boolean delete(int id);
	
	boolean addPurchaseDetails();
	
	boolean update();
	Map<Integer,Object> findAll();
}
