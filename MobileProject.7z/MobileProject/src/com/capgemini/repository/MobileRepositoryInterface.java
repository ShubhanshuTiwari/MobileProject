package com.capgemini.repository;

import java.util.List;
import java.util.Map;

import com.capgemini.bean.Mobile;



public interface MobileRepositoryInterface {
	
	boolean addMobile();
	boolean delete(int id);
	
	boolean create();
	
	boolean update();
}
